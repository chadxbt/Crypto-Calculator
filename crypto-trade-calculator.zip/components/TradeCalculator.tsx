import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function TradeCalculator() {
  const [entry, setEntry] = useState(0);
  const [stop, setStop] = useState(0);
  const [tp, setTp] = useState(0);
  const [risk, setRisk] = useState(0);
  const [leverage, setLeverage] = useState(1);
  const [result, setResult] = useState(null);

  const calculate = () => {
    const stopLossPerUnit = Math.abs(entry - stop);
    const profitPerUnit = Math.abs(tp - entry);

    const positionSize = risk / stopLossPerUnit;
    const totalPnL = profitPerUnit * positionSize;
    const marginRequired = (positionSize * entry) / leverage;

    setResult({
      positionSize: positionSize.toFixed(4),
      totalPnL: totalPnL.toFixed(2),
      marginRequired: marginRequired.toFixed(2),
    });
  };

  return (
    <div className="max-w-md mx-auto p-4 space-y-4">
      <Card>
        <CardContent className="space-y-2 pt-4">
          <Input type="number" placeholder="Entry Price" onChange={(e) => setEntry(parseFloat(e.target.value))} />
          <Input type="number" placeholder="Stop Loss Price" onChange={(e) => setStop(parseFloat(e.target.value))} />
          <Input type="number" placeholder="Take Profit Price" onChange={(e) => setTp(parseFloat(e.target.value))} />
          <Input type="number" placeholder="Risk Amount ($)" onChange={(e) => setRisk(parseFloat(e.target.value))} />
          <Input type="number" placeholder="Leverage (e.g. 100)" onChange={(e) => setLeverage(parseFloat(e.target.value))} />
          <Button onClick={calculate}>Calculate</Button>
          {result && (
            <div className="pt-4 space-y-2">
              <p><strong>Position Size:</strong> {result.positionSize} ETH</p>
              <p><strong>Estimated PnL:</strong> ${result.totalPnL}</p>
              <p><strong>Margin Required:</strong> ${result.marginRequired}</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
